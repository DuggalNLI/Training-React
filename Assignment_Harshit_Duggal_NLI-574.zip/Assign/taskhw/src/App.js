import React from 'react'
import Questhree from './Components/Questhree'
import Questone from './Components/Questone'
import Questwo from './Components/Questwo'
// import Foreg from './Components/foreg'

function App() {
  return (
    <>
      <Questone/>
      <Questwo/>
      <Questhree/>
      {/* <Foreg/> */}
    </>
  )
}

export default App